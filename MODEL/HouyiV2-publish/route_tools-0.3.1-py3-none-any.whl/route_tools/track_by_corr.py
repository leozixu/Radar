#  Copyright 2025 Junxiang Xiao
#
#  SPDX-License-Identifier: Apache-2.0
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.

"""
This module provides several functions for tracking routes according to
correlation matrix between points.

"""

import dataclasses
from functools import reduce
from typing import Optional, List, Set, Tuple

import numba
import numpy as np


def graph_tracking(
    corr_mat: np.ndarray,
    labels: Optional[np.ndarray] = None,
    corr_thresh: Optional[float] = None
) -> List[List[int]]:
    """
    Preform route tracking according to correlation matrix. This function
    converts correlation matrix into a binary adjacency matrix, which is
    used to build a graph containing all target points. The connected components
    of the graph give out tracked routes.

    Args:
        corr_mat: the correlation matrix between points, shape=(n_points,
            n_points).
        labels: Optional label information to assist tracking, shape=
            (n_points,), each element of which tells whether the point is
            classified as a true target. If not provided, all points are
            considered to be true targets.
        corr_thresh: Correlation values greater than :attr:`threshold` is treated
            as 1 otherwise as 0. If being None, the maximum value between the
            50% percentile of all values and mean of all values in
            :attr:`corr_mat` is used.

    Return:
         List of point sets of tracked routes.

    Note:
        This function won't return any single-point route.

    """
    import networkx as nx

    n_points = corr_mat.shape[0]
    if corr_thresh is None:
        corr_thresh = max(
            np.percentile(corr_mat, 50),
            np.mean(corr_mat)
        )

    bin_corr_mat = np.where(
        corr_mat > corr_thresh,
        corr_mat, 0
    )
    nodelist = np.arange(n_points)

    if labels is not None:
        target_idx_mask = labels > 0
        bin_corr_mat = bin_corr_mat[target_idx_mask][:, target_idx_mask]
        nodelist = np.where(target_idx_mask)[0]

    g: nx.Graph = nx.from_numpy_array(bin_corr_mat)
    g = nx.relabel_nodes(
        g,
        mapping=dict(zip(range(len(nodelist)), nodelist))
    )
    routes = list(list(comp) for comp in nx.connected_components(g)
                  if len(comp) > 1)
    return routes


def max_corr_tracking(
    corr_mat: np.ndarray,
    coords: np.ndarray,
    circle_ids: np.ndarray,
    labels: Optional[np.ndarray] = None,
    dist_thresh: Optional[float] = None,
    corr_thresh: Optional[float] = None
) -> List[List[int]]:
    """
    Preform route tracking according to correlation matrix.

    Args:
        corr_mat: the correlation matrix between points, shape=(n_points,
            n_points)
        coords: (t, x, y) coordinates of points, shape=(n_points, 3)
        circle_ids: Circle IDs of all points, shape=(n_points,).
        labels: Optional label information to assist tracking, shape=
            (n_points,), each element of which tells whether the point is
            classified as a true target. If not provided, all points are
            considered to be true targets.
        dist_thresh: For each point to be associated, only those points the
            distance to which does not exceed :attr:`dist_thresh` will be
            considered.
        corr_thresh: Correlation values greater than :attr:`corr_thresh` is
            treated as 1 otherwise as 0. If being None, the maximum value
            between the 50% percentile of all values and mean of all values in
            :attr:`corr_mat` is used.

    Return:
        List of point sets of tracked routes.

    """
    n_points = corr_mat.shape[0]

    if dist_thresh is not None:
        xys = coords[:, 1:3]
        dists = np.linalg.norm(
            np.expand_dims(xys, 0) - np.expand_dims(xys, 1),
            axis=-1
        )  # shape=(n_points, n_points)
        corr_mat[dists > dist_thresh] = 0

    if corr_thresh is None:
        corr_thresh = max(
            np.percentile(corr_mat, 50),
            np.mean(corr_mat)
        )
    corr_mat = np.where(
        corr_mat > corr_thresh,
        corr_mat, 0
    )

    target_point_indices = np.arange(n_points)
    if labels is not None:
        target_idx_mask = labels > 0
        target_point_indices = np.where(target_idx_mask)[0]
        # shape=(n_targets,)

    target_point_coords = coords[target_point_indices]
    circ_id_set = np.sort(np.unique(circle_ids))
    target_circle_ids = circle_ids[target_point_indices]

    routes = []  # [{point_indices}, ...]
    point_route_map = {}  # {point_idx: route_idx, ...}
    circ_target_map = {
        _circ: target_point_indices[target_circle_ids == _circ]
        for _circ in circ_id_set
    }  # {circle_id: [target_index, ...]} map
    for circ_id in circ_id_set:
        # For each circ_id, associating corresponding points by handling the
        # following sub-matrix (noted as `sub_corr`):
        #                1           2               m       ←─ column_idx
        #               t1          t2              tm       ←─ targets in prev. circles
        #  1  p1  ┌ c[p1, t1]   c[p1, t2]  ...  c[p1, tm] ┐
        #  2  p2  │ c[p2, t1]   c[p2, t2]  ...  c[p2, tm] │
        #         │                                       │
        #  n  pn  └ c[pn, t1]   c[pn, t2]  ...  c[pn, tm] ┘
        #  ↑   ↑
        #  │   └─ points in circle `circ_id`
        #  └───── row_idx
        # where c is `corr_mat`.

        points_in_circ = circ_target_map[circ_id]
        prev_targets = target_point_indices[target_circle_ids < circ_id]

        if np.size(prev_targets) == 0:  # targets in the first circle
            for row_idx in points_in_circ:
                routes.append([row_idx])  # each target starts a new route
                point_route_map[row_idx] = len(routes) - 1
            continue

        sub_corr = corr_mat[points_in_circ][:, prev_targets]
        # shape=(len(points_in_circ), len(prev_targets))
        row_indices, column_indices = np.meshgrid(
            np.arange(len(points_in_circ)),
            np.arange(len(prev_targets)),
            indexing="ij"
        )  # mesh grid indices of elements in matrix `sub_corr`

        while row_indices.size > 0:
            flatten_idx_max_corr = np.argmax(sub_corr)
            row_idx = row_indices.ravel()[flatten_idx_max_corr]
            col_idx = column_indices.ravel()[flatten_idx_max_corr]
            corr = sub_corr[row_idx, col_idx]
            if corr > 0:
                prev_target = prev_targets[col_idx]
                # the global ID of the associated target
                point = points_in_circ[row_idx]
                # the global ID of the point

                route_id = point_route_map[prev_target]
                routes[route_id].append(point)
                point_route_map[point] = route_id

            else:
                point = points_in_circ[row_idx]
                # the global ID of the point
                routes.append([point])
                route_id = len(routes) - 1
                point_route_map[point] = route_id

            # Update information of points and routes remained to be
            # associated
            points_in_circ = np.delete(points_in_circ, row_idx)
            # remove all targets in the route of `route_id`, since this
            # route has be associated and in the same circle only one point
            # can be associated to a route:
            # TODO: TAS?
            prev_targets = prev_targets[
                ~np.isin(prev_targets, list(routes[route_id]))
            ]

            sub_corr = corr_mat[points_in_circ][:, prev_targets]
            # shape=(len(points_in_circ), len(prev_targets))
            row_indices, column_indices = np.meshgrid(
                np.arange(len(points_in_circ)),
                np.arange(len(prev_targets)),
                indexing="ij"
            )  # mesh grid indices of elements in matrix `sub_corr`

        # Handling remaining not associated points
        if len(points_in_circ) > 0:
            for pid in points_in_circ:
                routes.append([pid])
                route_id = len(routes) - 1
                point_route_map[pid] = route_id

    return routes


@numba.njit(cache=True)
def _call_scoring_reduce_fn(
    a: np.ndarray,
    reduce_fn_name: str
):
    if reduce_fn_name == "mean":
        return np.mean(a)
    if reduce_fn_name == "max":
        return np.max(a)
    if reduce_fn_name == "min":
        return np.min(a)

    raise ValueError(f"Currently {reduce_fn_name} is not supported.")
    # reduce_fn = getattr(np, reduce_fn_name, None)

    # if reduce_fn is None:
    #     raise ValueError("Input reduce_fn_name cannot be found in numpy namespace "
    #                      f"(i.e. there is no `numpy.{reduce_fn_name}` function).")
    # return reduce_fn(a)


@numba.njit(cache=True, parallel=True)
def score_point_routes(
    corr: np.ndarray,
    prev_point_rids: np.ndarray,
    reduce_fn_name: str = "mean",
    score_decrement_for_1p_route: float = 0.
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Evaluate point-route scores.

    Args:
        corr: shape=(n_current_circ_points, n_lookback_points)
        prev_point_rids: shape=(n_lookback_points,)
        reduce_fn_name: Function to evaluate point-route score from multi-circle
            historical correlation values of each route. Available options are
            "mean", "max", "min".
        score_decrement_for_1p_route: For routes which only contain 1 point in
            previous circles, all its point-route scores will be decremented by
            this value.

    Returns:
        - scores, shape=(n_current_circ_points, n_lookback_routes)
        - route_id_set, shape=(n_lookback_routes,), each element corresponds
            to a row of `scores`

    Note:
        If :attr:`score_decrement_for_1p_route` is set, elements in returned
        :attr:`scores` may be negative rather than stay in range [0, 1].

    """
    route_id_set = np.sort(np.unique(prev_point_rids))
    scores = np.zeros((corr.shape[0], len(route_id_set)), dtype=np.float64)

    for i_point in numba.prange(corr.shape[0]):
        point_corrs = corr[i_point]
        for i_route in numba.prange(len(route_id_set)):
            route_id = route_id_set[i_route]

            route_prev_points_mask = prev_point_rids == route_id
            pr_corrs = point_corrs[route_prev_points_mask]
            scores[i_point, i_route] = _call_scoring_reduce_fn(pr_corrs, reduce_fn_name)

            if np.sum(route_prev_points_mask) == 1:
                scores[i_point, i_route] -= score_decrement_for_1p_route

    return scores, route_id_set


@numba.njit(cache=True)
def asso_by_point_routes_scores(
    scores: np.ndarray,
    point_ids: np.ndarray,
    route_ids: np.ndarray,
    score_thresh: float = 0.5
) -> numba.types.int64[:]:
    """

    Args:
        scores: scores between points and routes, shape=(n_points, n_routes)
        point_ids: shape=(n_points,)
        route_ids: shape=(n_routes,)
        score_thresh: Threshold for point-route association. Point-route
            pairs whose scores are smaller than this value will not be associated.

    Returns:
        Associated route IDs of each point, shape=(n_points,). If a point does
        not associated to any route, corresponding route ID will be -1.

    """
    avail_point_id_set = set(point_ids)
    avail_route_id_set = set(route_ids)

    if scores.shape != (len(point_ids), len(route_ids)):
        raise ValueError(
            f"The shape of `scores` ({scores.shape}) doesn't match lengths of "
            f"`point_ids` and `route_ids` ({len(point_ids)}, {len(route_ids)})."
        )

    if len(avail_point_id_set) < len(point_ids):
        raise ValueError(
            "Duplicated point IDs found in `point_ids`"
        )
    if len(avail_route_id_set) < len(route_ids):
        raise ValueError(
            "Duplicated route IDs found in `route_ids`"
        )

    points_route_ids = np.ones(len(point_ids), dtype=np.int64) * (-1)

    sorted_flat_indices = np.argsort(np.ravel(scores))
    # inverse iteration (descending order of scores):
    for i_flat in sorted_flat_indices[::-1]:
        i_point, i_route = np.divmod(i_flat, len(route_ids))
        _score = scores[i_point, i_route]

        if _score < score_thresh:
            break

        point_id = point_ids[i_point]
        route_id = route_ids[i_route]

        if point_id not in avail_point_id_set or route_id not in avail_route_id_set:
            continue

        points_route_ids[i_point] = route_id

        avail_route_id_set.remove(route_id)
        avail_point_id_set.remove(point_id)

    return points_route_ids


@numba.njit(cache=True)
def multicirc_lookback_tracking_impl(
    corr_mat: np.ndarray,
    coords: np.ndarray,
    circle_ids: np.ndarray,
    labels: Optional[np.ndarray] = None,
    dist_thresh: Optional[float] = None,
    corr_thresh: Optional[float] = None,
    lookback_n_circles: int = 1,
    reduce_fn_name: str = "mean",
    score_decrement_for_1p_route: float = 0.1
) -> numba.typed.List[numba.types.int64[:]]:
    n_points = corr_mat.shape[0]

    if dist_thresh is not None:
        xys = coords[:, 1:3]
        dists = np.zeros((n_points, n_points), dtype=np.float64)

        for i in range(n_points):
            xy_i = xys[i]
            for j in range(n_points):
                xy_j = xys[j]
                dists[i, j] = np.sqrt(np.sum((xy_i - xy_j) ** 2))

                if dists[i, j] > dist_thresh:
                    corr_mat[i, j] = 0.

    if corr_thresh is None:
        corr_thresh = max(
            np.percentile(corr_mat, 50),
            np.mean(corr_mat)
        )
    corr_mat = np.where(
        corr_mat > corr_thresh,
        corr_mat, 0
    )

    circ_id_set = np.sort(np.unique(circle_ids))

    routes = numba.typed.List.empty_list(numba.types.int64[:])  # [[point_indices], ...]
    point_route_map = numba.typed.Dict.empty(
        key_type=numba.types.int64,
        value_type=numba.types.int64
    )  # {point_idx: route_idx, ...}

    circ_target_map = numba.typed.Dict.empty(
        key_type=numba.types.int64,
        value_type=numba.types.int64[:]
    )  # {circle_id: [target_index, ...]} map
    for i_point in range(n_points):
        if labels is not None and not labels[i_point]:
            continue

        i_point_cid = circle_ids[i_point]

        if i_point_cid not in circ_target_map:
            circ_target_pids = np.array((), dtype=np.int64)
        else:
            circ_target_pids = circ_target_map[i_point_cid]
        circ_target_map[i_point_cid] = np.append(circ_target_pids, i_point)

    for circ_id in circ_id_set:
        # For each circ_id, associating corresponding points by handling the
        # following sub-matrix (noted as `sub_corr`):
        #                1           2               m       ←─ column_idx
        #               t1          t2              tm       ←─ targets in prev. circles
        #  1  p1  ┌ c[p1, t1]   c[p1, t2]  ...  c[p1, tm] ┐
        #  2  p2  │ c[p2, t1]   c[p2, t2]  ...  c[p2, tm] │
        #         │                                       │
        #  n  pn  └ c[pn, t1]   c[pn, t2]  ...  c[pn, tm] ┘
        #  ↑   ↑
        #  │   └─ points in circle `circ_id`
        #  └───── row_idx
        # where c is `corr_mat`.

        if circ_id not in circ_target_map:  # Skip the circle where there is no targets
            continue

        targets_in_circ: numba.types.int64[:] = circ_target_map[circ_id]
        prev_targets = np.array((), dtype=np.int64)
        for _circ_id in range(circ_id - lookback_n_circles, circ_id):
            if _circ_id not in circ_target_map:
                continue
            prev_targets = np.concatenate((prev_targets, circ_target_map[_circ_id]))

        if prev_targets.size == 0:  # targets in the first circle
            for row_idx in targets_in_circ:
                routes.append(np.array((row_idx,), dtype=np.int64))  # each target starts a new route
                point_route_map[row_idx] = len(routes) - 1
            continue

        sub_corr = corr_mat[targets_in_circ][:, prev_targets]
        # shape=(len(targets_in_circ), len(prev_targets))
        scores, route_id_set = score_point_routes(
            sub_corr,
            np.array([point_route_map[pid] for pid in prev_targets]),
            reduce_fn_name,
            score_decrement_for_1p_route
        )
        # shape=(len(targets_in_circ), len(route_id_set) i.e. num_route_ids_of_prev_targets)

        asso_points_route_ids = asso_by_point_routes_scores(
            scores,
            targets_in_circ,
            route_id_set,
            score_thresh=corr_thresh
        )
        for i_point in range(len(asso_points_route_ids)):
            point_id = targets_in_circ[i_point]
            asso_route_id = asso_points_route_ids[i_point]

            if asso_route_id == -1:
                routes.append(np.array((point_id,), dtype=np.int64))
                point_route_map[point_id] = len(routes) - 1
            else:
                routes[asso_route_id] = np.append(routes[asso_route_id], point_id)
                point_route_map[point_id] = asso_route_id

    return routes


def multicirc_lookback_tracking(
    corr_mat: np.ndarray,
    coords: np.ndarray,
    circle_ids: np.ndarray,
    labels: Optional[np.ndarray] = None,
    dist_thresh: Optional[float] = None,
    corr_thresh: Optional[float] = None,
    lookback_n_circles: int = 1,
    reduce_fn_name: str = "mean",
    score_decrement_for_1p_route: float = 0.1
) -> list[list[int]]:
    """
    Preform route tracking according to correlation matrix.

    Args:
        corr_mat: the correlation matrix between points, shape=(n_points,
            n_points)
        coords: (t, x, y) coordinates of points, shape=(n_points, 3)
        circle_ids: circle IDs of all points, shape=(n_points,)
        labels: Optional label information to assist tracking, shape=
            (n_points,), each element of which tells whether the point is
            classified as a true target. If not provided, all points are
            considered to be true targets.
        dist_thresh: For each point to be associated, only those points the
            distance to which does not exceed :attr:`dist_thresh` will be
            considered.
        corr_thresh: Correlation values greater than :attr:`corr_thresh` is
            treated as 1 otherwise as 0. If being None, the maximum value
            between the 50% percentile of all values and mean of all values in
            :attr:`corr_mat` is used.
        lookback_n_circles: Number of circles to look back for evaluation
            point-route scores. By default, only one previous circle is
            considered.
        reduce_fn_name: Function to evaluate point-route score from multi-circle
            historical correlation values of each route.
        score_decrement_for_1p_route: For routes which only contain 1 point in
            previous circles, all its point-route scores will be decremented by
            this value.

    Return:
        List of point sets of tracked routes.

    """
    tracked_routes_impl = multicirc_lookback_tracking_impl(
        np.ascontiguousarray(corr_mat),
        coords,
        circle_ids,
        labels,
        dist_thresh,
        corr_thresh,
        lookback_n_circles,
        reduce_fn_name,
        score_decrement_for_1p_route
    )
    tracked_routes = [list(route) for route in tracked_routes_impl]
    return tracked_routes


@dataclasses.dataclass
class AssociatingStatistic:
    correct: int
    total: int

    def __add__(self, other) -> "AssociatingStatistic":
        return AssociatingStatistic(
            correct=self.correct + other.correct,
            total=self.total + other.total
        )

    def __iadd__(self, other) -> "AssociatingStatistic":
        self.correct += other.correct
        self.total += other.total
        return self

    @property
    def accuracy(self) -> float:
        if self.total == 0:
            return np.nan
        return self.correct / self.total

    def __eq__(self, other):
        if not isinstance(other, AssociatingStatistic):
            return False
        return (self.correct == other.correct
                and self.total == other.total)


def associating_accuracy(
    track_result: List[List[int]],
    true_route_ids: np.ndarray,
    labels: Optional[np.ndarray] = None
) -> AssociatingStatistic:
    """
    Estimate the associating accuracy.

    Args:
        track_result: Point lists of tracked routes.
        true_route_ids: True route IDs of all points, shape=(n_points,).
        labels: Optional label information to assist tracking, shape=
            (n_points,), each element of which tells whether the point is
            labelled as a true target. If not provided, all points are
            considered to be true targets. Note that different from the
            :attr:`labels` argument of :py:func:`multicirc_lookback_tracking`,
            this argument must be **TRUE** labels.

    Return:
        The associating statistic object, containing the count of correctly
        associated points and total number of points.

    """
    n_points = true_route_ids.size

    tracked_points: Set[int] = reduce(lambda r1, r2: set(r1).union(set(r2)),
                                      track_result, set())
    not_tracked_points: Set[int] = set(range(n_points)) - tracked_points

    correct = 0
    for tracked_route_pids in track_result:
        tracked_route_rids = true_route_ids[tracked_route_pids]
        correct += np.sum(
            (tracked_route_rids[1:] == tracked_route_rids[:-1]) &
            (labels is None or labels[tracked_route_pids][1:])
        )

        # If the first point of tracked route is a true target and
        # is indeed the starting point of its route:
        if (
            (labels is None or labels[tracked_route_pids[0]]) and
            (np.where(true_route_ids == tracked_route_rids[0])[0][0]
             == tracked_route_pids[0])
        ):
            correct += 1

    if labels is None:
        false_points = set()
    else:
        false_points = set(np.where(~labels)[0])
    correct += len(not_tracked_points & false_points)

    return AssociatingStatistic(
        correct, n_points
    )
